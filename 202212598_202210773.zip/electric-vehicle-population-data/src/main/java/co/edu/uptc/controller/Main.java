package co.edu.uptc.controller;

import co.edu.uptc.controller.Controller;
import co.edu.uptc.model.GeographicAnalysis;


public class Main {
    public static void main(String[] args) {
        
        Controller Controller = new Controller();
    }
}
