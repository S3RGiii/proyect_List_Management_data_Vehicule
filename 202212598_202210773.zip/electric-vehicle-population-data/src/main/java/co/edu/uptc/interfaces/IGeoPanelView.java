
package co.edu.uptc.interfaces;

import javax.swing.JPanel;

public interface IGeoPanelView {
    public void addPanel(JPanel panel);

}
