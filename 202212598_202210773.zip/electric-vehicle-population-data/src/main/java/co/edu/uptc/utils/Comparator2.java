package co.edu.uptc.utils;

public class Comparator2 {
    
}
