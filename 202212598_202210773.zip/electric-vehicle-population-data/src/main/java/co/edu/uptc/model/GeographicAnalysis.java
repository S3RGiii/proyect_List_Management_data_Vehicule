package co.edu.uptc.model;

import java.util.Comparator;
import java.util.List;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import co.edu.uptc.utils.LinkedListSorter;
import co.edu.uptc.utils.MyList;
import co.edu.uptc.utils.Node;

public class GeographicAnalysis {
    private MyList<Vehicule> records;
    private LinkedListSorter<Vehicule> sorter;


    public GeographicAnalysis(MyList<Vehicule> records) {
        this.records = records;
        sorter = new LinkedListSorter<>();
    }
    public TableModel getRecordsByCountyAndState() {
        MyList<Vehicule> sortedRecords = this.records;
        DefaultTableModel tableModel = new DefaultTableModel(new Object[]{"State", "County", "Count"}, 0);

        sortedRecords.forEach(record -> {
            String state = record.getState();
            String county = record.getCounty();
            int count = 0;

            for (Vehicule vehicule : sortedRecords) {
                if (vehicule.getState().equals(state) && vehicule.getCounty().equals(county)) {
                    count++;
                }
            }

            tableModel.addRow(new Object[]{state, county, count});
        });

        return tableModel;
    }
    




    @SuppressWarnings("unchecked")
    public MyList<Vehicule> getRecordsByState() {

        Comparator<Vehicule> stateComparator = new Comparator<Vehicule>() {
            @Override
            public int compare(Vehicule o1, Vehicule o2) {
                return o1.getState().compareTo(o2.getState());
            }
        };
        Node<Vehicule> nhead = sorter.sort(records.getHead(), stateComparator);
        records.setHead(nhead);
        return records;
    }

    
    
   
}
