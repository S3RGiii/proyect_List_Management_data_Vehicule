package co.edu.uptc.view;
import java.awt.Font;

public class ConstantsGUI{
	
	
	public static final Font FONT_BUSCAR= new Font("Comic Sans MS", Font.PLAIN, 18);
	public static final Font FONT_PANEL_RIGHT= new Font("Comic Sans MS", Font.PLAIN,18);
	
	public static final Font FONT_PANEL_LEFT= new Font("Verdana", Font.PLAIN, 40);
	

}
