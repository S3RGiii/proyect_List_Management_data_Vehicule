package co.edu.uptc.utils;

import java.util.Comparator;

public class LinkedListSorter<T> {

    public Node<T> sort(Node<T> head, Comparator<T> comparator) {
        if (head == null || head.getNext() == null) {
            return head;
        }

        Node<T> middle = getMiddle(head);
        Node<T> nextOfMiddle = middle.getNext();

        middle.setNext(null);

        Node<T> left = sort(head, comparator);
        Node<T> right = sort(nextOfMiddle, comparator);

        return merge(left, right, comparator);
    }

    // Helper method to get the middle of the linked list
    private Node<T> getMiddle(Node<T> head) {
        if (head == null) {
            return head;
        }

        Node<T> slow = head;
        Node<T> fast = head.getNext();

        while (fast != null) {
            fast = fast.getNext();
            if (fast != null) {
                slow = slow.getNext();
                fast = fast.getNext();
            }
        }

        return slow;
    }

    // Helper method to merge two sorted linked lists
    private Node<T> merge(Node<T> left, Node<T> right, Comparator<T> comparator) {
        if (left == null) {
            return right;
        }

        if (right == null) {
            return left;
        }

        if (comparator.compare(left.getData(), right.getData()) <= 0) {
            left.setNext(merge(left.getNext(), right, comparator));
            return left;
        } else {
            right.setNext(merge(left, right.getNext(), comparator));
            return right;
        }
    }
}
